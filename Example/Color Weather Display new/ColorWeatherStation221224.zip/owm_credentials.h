// Change to your WiFi credentials
const char* ssid     = "xxxxxxxxx";     // WiFi SSID to connect to
const char* password = "xxxxxxxxx"; // WiFi password needed for the SSID
const char* sensora = "http://192.168.xxx.xxx/getValues"; //  for the 1.-WLAN-Sensor
const char* sensorb = "http://192.168.xxx.xxx/getValues"; //  for the 2.-WLAN-Sensor
// Use your own API key by signing up for a free developer account at https://openweathermap.org/
String apikey         = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";                  // See: https://openweathermap.org/  // It's free to get an API key, but don't take more than 60 readings/minute!
const char server[] = "api.openweathermap.org";
String LAT              = "51.51";                         // Home location Latitude
String LON              = "5.85";                         // Home location Longitude
String City             = "My Cityname ";                      // Your home city See: http://bulk.openweathermap.org/sample/
String Country          = "DE";                            // Your _ISO-3166-1_two-letter_country_code country code, on OWM find your nearest city and the country code is displayed
String Language         = "DE";                            // NOTE: Only the weather description is translated by OWM
String Hemisphere       = "north";                         // or "south"  
String Units            = "M";                             // Use 'M' for Metric or I for Imperial 
const char* Timezone    = "CET-1CEST,M3.5.0,M10.5.0/3";  // Choose your time zone from: https://github.com/nayarsystems/posix_tz_db/blob/master/zones.csv 
const char* ntpServer   = "0.europe.pool.ntp.org";             // Or, choose a time server close to you, but in most cases it's best to use pool.ntp.org to find an NTP server
int   gmtOffset_sec     = 0;    // UK normal time is GMT, so GMT Offset is 0, for US (-5Hrs) is typically -18000, AU is typically (+8hrs) 28800
int  daylightOffset_sec = 3600; // In the UK DST is +1hr or 3600-secs, other countries may use 2hrs 7200 or 30-mins 1800 or 5.5hrs 19800 Ahead of GMT use + offset behind - offset
//Schaltuhr
const int OnHour = 6;
const int OnMin = 31;
const int OffHour = 22;
const int OffMin = 15;